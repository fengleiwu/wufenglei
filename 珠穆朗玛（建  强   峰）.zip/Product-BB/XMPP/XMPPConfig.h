//
//  XMPPConfig.h
//  XMPPSample
//
//  Created by lewis on 14-3-27.
//  Copyright (c) 2014年 com.lanou3g. All rights reserved.
//

#ifndef XMPPSample_XMPPConfig_h
#define XMPPSample_XMPPConfig_h

//openfire服务器IP地址
#define  kHostName      @"127.0.0.1"
//openfire服务器端口 默认5222
#define  kHostPort      5222
//openfire域名
#define kDomin @"linjiandemacbook-pro.local"
//resource
#define kResource @"iOS"
#endif
