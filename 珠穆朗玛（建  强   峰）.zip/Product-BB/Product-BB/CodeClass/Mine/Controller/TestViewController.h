//
//  TestViewController.h
//  Product-BB
//
//  Created by 林建 on 16/7/20.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestViewController : UIViewController
@property (nonatomic, strong)NSString *phoneStr;
@end
