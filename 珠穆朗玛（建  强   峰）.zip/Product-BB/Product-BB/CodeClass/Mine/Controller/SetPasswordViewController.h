//
//  SetPasswordViewController.h
//  Product-BB
//
//  Created by 林建 on 16/7/21.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetPasswordViewController : UIViewController
@property (nonatomic, strong)NSString *phoneStr;
@property (nonatomic, strong)NSString *petName;
@end
