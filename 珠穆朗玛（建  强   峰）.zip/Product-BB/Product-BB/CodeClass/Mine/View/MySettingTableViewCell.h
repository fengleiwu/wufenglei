//
//  MySettingTableViewCell.h
//  Product-BB
//
//  Created by 林建 on 16/7/19.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MySettingTableViewCell : UITableViewCell
@property (nonatomic, strong)UIButton *imageB;
@property (nonatomic, strong)UILabel *label;
@property (nonatomic, strong)UIImageView *nextV;

@end
