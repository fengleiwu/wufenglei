//
//  BroadcastViewController.h
//  Product-BB
//
//  Created by 林建 on 16/7/12.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BroadcastViewController : UIViewController
@property (nonatomic, assign)CGFloat buttonWidth;
@property (nonatomic, assign)CGFloat buttonHeight;
@end
