//
//  OtherProgramViewController.h
//  Product-BB
//
//  Created by 林建 on 16/7/16.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OtherProgramViewController : UIViewController
@property (nonatomic, strong)NSString *urlStr;
@property (nonatomic, strong)NSString *titleStr;
@property (nonatomic, assign)NSInteger indexC;
@end
