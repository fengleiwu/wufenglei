//
//  batchDownViewController.h
//  Product-BB
//
//  Created by lanou on 16/7/20.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface batchDownViewController : UIViewController


@property(nonatomic , strong)NSMutableArray *arr;

@property(nonatomic , strong)NSString *coverMiddle;

@property(nonatomic , strong)NSString *titleL;

@end
