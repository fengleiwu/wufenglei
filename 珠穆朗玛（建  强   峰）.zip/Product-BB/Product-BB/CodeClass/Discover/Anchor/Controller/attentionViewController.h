//
//  attentionViewController.h
//  Product-BB
//
//  Created by lanou on 16/7/17.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface attentionViewController : UIViewController
@property(nonatomic , strong)NSString *Uid;
@end
