//
//  PlayListView.h
//  Product-BB
//
//  Created by lanou on 16/7/18.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayListView : UIView

@property (nonatomic, strong) NSMutableArray *tableViewArr;

@end
