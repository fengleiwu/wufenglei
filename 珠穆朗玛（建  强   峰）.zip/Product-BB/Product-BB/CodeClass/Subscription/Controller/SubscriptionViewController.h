//
//  SubscriptionViewController.h
//  Product-BB
//
//  Created by lanou on 16/7/11.
//  Copyright © 2016年 lanou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubscriptionViewController : UIViewController
@property (nonatomic, assign)BOOL isClick;
@property (nonatomic, assign)BOOL All;
@end
